﻿Public Class Form3
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MsgBox("Еркебулан - способный мальчик. Учит абсолютно все уроки на отлично. Выборочный предмет - биология, олимпийец по математике. Очень разносторонний и несмотря на то, что не особо интересуется физикой, искусством и другими малозначимыми для него уроками, ведёт их лишь на отличные оценки. Занимается футболом, креативный.")
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        MsgBox("Абылай - мышлитель. Креативный подход и неординарное мышление выделяет его от остальных. Выборочный предмет - информатика. Именно на основе этого урока изобрёл мобильное приложение, в честь чего был удостоен сертификата первой степени на конференции в КазНу. По правде говоря, кроме математики, физики и особено информатики он ничем не увлекается. ")
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        MsgBox("Ельнур - необычный. Креативный подход и неординарное мышление выделяет его от остальных. Выборочный предмет - информатика. По правде говоря, кроме математики, физики и особено информатики он ничем не увлекается.")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        MsgBox("Айжан - умная, веселая, разносторонняя. Умеет находить решение при любой проблеме и задаче.")
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        MsgBox("Акбаян - умная, веселая, разносторонняя. Умеет находить решение при любой проблеме и задаче.")
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        MsgBox("Жания - совсем другой человеческий тип. Своими непредсказуемыми решениями и стремлениями идти только вперёд, она поражает всех. На высоком ровне учит физику.")
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        MsgBox("Гульназ - очень хорошо запоминающая девушка. Всю полученную информацию запоминает в ммиг и умеет использовать это в определнные моменты")
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        MsgBox("Арыстанбек - 100 уроень креативности и оптимизма.")
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        MsgBox("Демеу - 100 уроень спорта и мускулизма.")
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        MsgBox("Амиршаир - креативная личность с необычным подходом ко всему. Умеет выслушивать и уважать других людей")
    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        Form2.Show()
    End Sub
End Class