﻿Public Class Form2
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "Thenotorious" And TextBox2.Text = "4526" Then
            Form3.Show()
            Me.Hide()
        Else
            MsgBox("Не правильный логин или пароль!Пожалуйста введите свои данные еще раз!", 16, "Error")
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub
End Class