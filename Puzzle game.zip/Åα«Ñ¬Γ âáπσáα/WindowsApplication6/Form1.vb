﻿Public Class Form1
    Public count As Integer

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        '2,5,7,10
        checkButton(Button6, Button2)
        checkButton(Button6, Button5)
        checkButton(Button6, Button7)
        checkButton(Button6, Button10)
        checksolved()
    End Sub

    Private Sub Button16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button16.Click
        '12,15
        checkButton(Button16, Button12)
        checkButton(Button16, Button15)
        checksolved()
    End Sub

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        '13,10,15
        checkButton(Button14, Button13)
        checkButton(Button14, Button10)
        checkButton(Button14, Button15)
        checksolved()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
       
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        '1,3,6
        checkButton(Button2, Button1)
        checkButton(Button2, Button3)
        checkButton(Button2, Button6)
        checksolved()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        '2,4,7
        checkButton(Button3, Button2)
        checkButton(Button3, Button4)
        checkButton(Button3, Button7)
        checksolved()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        '3,8
        checkButton(Button4, Button3)
        checkButton(Button4, Button8)
        checksolved()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        '1,6,9
        checkButton(Button5, Button1)
        checkButton(Button5, Button6)
        checkButton(Button5, Button9)
        checksolved()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        '3,6,8,11
        checkButton(Button7, Button3)
        checkButton(Button7, Button6)
        checkButton(Button7, Button8)
        checkButton(Button7, Button11)
        checksolved()
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        '4,7,12
        checkButton(Button8, Button4)
        checkButton(Button8, Button7)
        checkButton(Button8, Button12)
        checksolved()
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        '5,10,13
        checkButton(Button9, Button5)
        checkButton(Button9, Button10)
        checkButton(Button9, Button13)
        checksolved()
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        '6,9,11,14
        checkButton(Button10, Button6)
        checkButton(Button10, Button9)
        checkButton(Button10, Button11)
        checkButton(Button10, Button14)
        checksolved()
    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        '7,10,12,15
        checkButton(Button11, Button7)
        checkButton(Button11, Button10)
        checkButton(Button11, Button12)
        checkButton(Button11, Button15)
        checksolved()
    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        '8.11.16
        checkButton(Button12, Button8)
        checkButton(Button12, Button11)
        checkButton(Button12, Button16)
        checksolved()
    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        '9,14
        checkButton(Button13, Button9)
        checkButton(Button13, Button14)
        checksolved()
    End Sub

    Private Sub Button15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button15.Click
        '14,11,16
        checkButton(Button15, Button14)
        checkButton(Button15, Button11)
        checkButton(Button15, Button16)
        checksolved()
    End Sub

    Private Sub ToolStripButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton2.Click
        Me.Close()

    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim x = MsgBox("Do you want to Exit ?", vbYesNo + vbQuestion)
        If (x = Windows.Forms.DialogResult.No) Then
            e.Cancel = True
        End If
    End Sub

    Private Sub ToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton1.Click
        Shuffle()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Shuffle()
    End Sub

    Private Sub ToolStrip1_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles ToolStrip1.ItemClicked

    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        '2,5
        checkButton(Button1, Button2)
        checkButton(Button1, Button5)
        checksolved()
    End Sub

    Private Sub Button17_Click(sender As Object, e As EventArgs)
        Me.Hide()
        Form3.Show()
    End Sub

    Private Sub Button17_Click_1(sender As Object, e As EventArgs) Handles Button17.Click
        Form3.Show()
    End Sub
End Class
