﻿Public Class Form2
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox6.Text = My.Settings.Логин AndAlso TextBox5.Text = My.Settings.Пароль Then
            Form3.Show()
            Me.Hide()
        Else
            MsgBox("Были введены неправильные данные, повторите попытку или зарегистрируйтесь")
        End If
        'Проверяется, есть ли схожие варианты пароля и логина в базе данных, 
        'есть ли сходится, то проходит аутентификацию и переходит на форму 2
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If TextBox4.Text = "" Or TextBox3.Text = "" Then
            MsgBox("Пожалуйста, введите значения")
        Else
            My.Settings.Логин = TextBox4.Text
            My.Settings.Пароль = TextBox3.Text
            My.Settings.Save()
            MsgBox("Регистрация прошла успешно")
            'Записывается логин и пароль и регистрируется пользователь
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If TextBox6.Text = My.Settings.Логин AndAlso TextBox5.Text = My.Settings.Пароль Then
            Form1.Show()
            Me.Hide()
        Else
            MsgBox("Были введены неправильные данные, повторите попытку или зарегистрируйтесь")
        End If
        'Проверяется, есть ли схожие варианты пароля и логина в базе данных, 
        'есть ли сходится, то проходит аутентификацию и переходит на форму 2
    End Sub
End Class