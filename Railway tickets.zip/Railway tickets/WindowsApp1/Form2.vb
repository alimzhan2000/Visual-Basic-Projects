﻿Public Class Form2
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "Radana" And TextBox2.Text = "12345" Then
            Form1.Show()
        End If
    End Sub
End Class