﻿Public Class Form2
    Dim k As Integer
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "Dinara" And TextBox2.Text = "1234567" Then
            Form1.Show()
        End If
    End Sub
    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        Timer1.Enabled = True
    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        Timer1.Enabled = False
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        k = k + 1
        If k = 1 Then PictureBox1.Image = My.Resources._1
        If k = 2 Then PictureBox1.Image = My.Resources._2
        If k = 3 Then PictureBox1.Image = My.Resources._3
        If k = 4 Then PictureBox1.Image = My.Resources._4
        If k = 5 Then PictureBox1.Image = My.Resources._5
        If k = 6 Then PictureBox1.Image = My.Resources._6
        If k = 7 Then PictureBox1.Image = My.Resources._7
        If k = 8 Then PictureBox1.Image = My.Resources._8 : k = 0
    End Sub
End Class