
 If you want to try the program without compiling it, just change the file in the 

 folder "\Samples"

   "slidePuzzle.Change2exe"  TO

   "slidePuzzle.exe" and run it

 I have included an image of a corvette in the "\samples" folder too,

 to load and start playing the puzzle. Hope you like, Have fun :)).
