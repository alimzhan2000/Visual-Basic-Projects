﻿Public Class Form1
    Dim cena As Integer
    Dim k As Integer
    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        If RadioButton1.Checked Then
            cena = TextBox1.Text * 2000
        End If
        If RadioButton2.Checked Then
            cena = TextBox1.Text * 3000
        End If
        If RadioButton3.Checked Then
            cena = TextBox1.Text * 4000
        End If
        Button1.BackColor = System.Drawing.Color.FromName("Red")
        Label3.Text = cena
    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged

    End Sub

    Private Sub GroupBox3_Enter(sender As Object, e As EventArgs) Handles GroupBox3.Enter

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If RadioButton1.Checked Then
            cena = TextBox1.Text * 2000
        End If
        If RadioButton2.Checked Then
            cena = TextBox1.Text * 3000
        End If
        If RadioButton3.Checked Then
            cena = TextBox1.Text * 4000
        End If
        Button1.BackColor = System.Drawing.Color.FromName("Red")
        Label3.Text = cena
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If RadioButton1.Checked Then
            cena = TextBox1.Text * 2000
        End If
        If RadioButton2.Checked Then
            cena = TextBox1.Text * 3000
        End If
        If RadioButton3.Checked Then
            cena = TextBox1.Text * 4000
        End If
        Button1.BackColor = System.Drawing.Color.FromName("Red")
        Label3.Text = cena
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If RadioButton1.Checked Then
            cena = TextBox1.Text * 2000
        End If
        If RadioButton2.Checked Then
            cena = TextBox1.Text * 3000
        End If
        If RadioButton3.Checked Then
            cena = TextBox1.Text * 4000
        End If
        Button1.BackColor = System.Drawing.Color.FromName("Red")
        Label3.Text = cena
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        If RadioButton1.Checked Then
            cena = TextBox1.Text * 2000
        End If
        If RadioButton2.Checked Then
            cena = TextBox1.Text * 3000
        End If
        If RadioButton3.Checked Then
            cena = TextBox1.Text * 4000
        End If
        Button1.BackColor = System.Drawing.Color.FromName("Red")
        Label3.Text = cena
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        If RadioButton1.Checked Then
            cena = TextBox1.Text * 2000
        End If
        If RadioButton2.Checked Then
            cena = TextBox1.Text * 3000
        End If
        If RadioButton3.Checked Then
            cena = TextBox1.Text * 4000
        End If
        Button1.BackColor = System.Drawing.Color.FromName("Red")
        Label3.Text = cena
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        If RadioButton1.Checked Then
            cena = TextBox1.Text * 2000
        End If
        If RadioButton2.Checked Then
            cena = TextBox1.Text * 3000
        End If
        If RadioButton3.Checked Then
            cena = TextBox1.Text * 4000
        End If
        Button1.BackColor = System.Drawing.Color.FromName("Red")
        Label3.Text = cena
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        If RadioButton1.Checked Then
            cena = TextBox1.Text * 2000
        End If
        If RadioButton2.Checked Then
            cena = TextBox1.Text * 3000
        End If
        If RadioButton3.Checked Then
            cena = TextBox1.Text * 4000
        End If
        Button1.BackColor = System.Drawing.Color.FromName("Red")
        Label3.Text = cena
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        If RadioButton1.Checked Then
            cena = TextBox1.Text * 2000
        End If
        If RadioButton2.Checked Then
            cena = TextBox1.Text * 3000
        End If
        If RadioButton3.Checked Then
            cena = TextBox1.Text * 4000
        End If
        Button1.BackColor = System.Drawing.Color.FromName("Red")
        Label3.Text = cena
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        If RadioButton1.Checked Then
            cena = TextBox1.Text * 2000
        End If
        If RadioButton2.Checked Then
            cena = TextBox1.Text * 3000
        End If
        If RadioButton3.Checked Then
            cena = TextBox1.Text * 4000
        End If
        Label3.Text = cena
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        If RadioButton1.Checked Then
            cena = TextBox1.Text * 2000
        End If
        If RadioButton2.Checked Then
            cena = TextBox1.Text * 3000
        End If
        If RadioButton3.Checked Then
            cena = TextBox1.Text * 4000
        End If
        Button1.BackColor = System.Drawing.Color.FromName("Red")
        Label3.Text = cena
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        If RadioButton1.Checked Then
            cena = TextBox1.Text * 2000
        End If
        If RadioButton2.Checked Then
            cena = TextBox1.Text * 3000
        End If
        If RadioButton3.Checked Then
            cena = TextBox1.Text * 4000
        End If
        Button1.BackColor = System.Drawing.Color.FromName("Red")
        Label3.Text = cena
    End Sub

    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        Form3.Show()
    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        Form4.Show()
    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        Form5.Show()
    End Sub
End Class
