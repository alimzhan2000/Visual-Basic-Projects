﻿Public Class Form3
    Dim k As Integer
    Private Sub GroupBox3_Enter(sender As Object, e As EventArgs)

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        Timer1.Enabled = True
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Timer1.Interval = 2000
        k = k + 1
        If k = 1 Then PictureBox1.Image = My.Resources.s1
        If k = 2 Then PictureBox1.Image = My.Resources.s2
        If k = 3 Then PictureBox1.Image = My.Resources.s3
        If k = 4 Then PictureBox1.Image = My.Resources.s4
        If k = 5 Then PictureBox1.Image = My.Resources.s5
        If k = 6 Then PictureBox1.Image = My.Resources.s6
        If k = 7 Then PictureBox1.Image = My.Resources.s7
        If k = 8 Then PictureBox1.Image = My.Resources.s8
        If k = 9 Then PictureBox1.Image = My.Resources.s9
        If k = 10 Then PictureBox1.Image = My.Resources.s10 : k = 0
    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        Timer1.Enabled = False
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub
End Class