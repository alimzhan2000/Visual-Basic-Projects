﻿Public Class Form5
    Dim k As Integer
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub
    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        Timer1.Enabled = True
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Timer1.Interval = 2000
        k = k + 1
        If k = 1 Then PictureBox1.Image = My.Resources.p1
        If k = 2 Then PictureBox1.Image = My.Resources.p2
        If k = 3 Then PictureBox1.Image = My.Resources.p3
        If k = 4 Then PictureBox1.Image = My.Resources.p4
        If k = 5 Then PictureBox1.Image = My.Resources.p5 : k = 0
    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        Timer1.Enabled = False
    End Sub
End Class