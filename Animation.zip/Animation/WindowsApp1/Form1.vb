﻿Public Class Form1
    Dim cena As Integer
    Dim k As Integer
    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If RadioButton1.Checked And RadioButton5.Checked Then
            cena = 2000
        End If
        If RadioButton2.Checked And RadioButton5.Checked Then
            cena = 3000
        End If
        If RadioButton3.Checked And RadioButton5.Checked Then
            cena = 6000
        End If
        If RadioButton1.Checked And RadioButton6.Checked Then
            cena = 4000
        End If
        If RadioButton2.Checked And RadioButton6.Checked Then
            cena = 6000
        End If
        If RadioButton3.Checked And RadioButton6.Checked Then
            cena = 12000
        End If
        Label3.Text = cena
        Button1.BackColor = System.Drawing.Color.FromName("Red")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If RadioButton1.Checked And RadioButton5.Checked Then
            cena = 2000
        End If
        If RadioButton2.Checked And RadioButton5.Checked Then
            cena = 3000
        End If
        If RadioButton3.Checked And RadioButton5.Checked Then
            cena = 6000
        End If
        If RadioButton1.Checked And RadioButton6.Checked Then
            cena = 4000
        End If
        If RadioButton2.Checked And RadioButton6.Checked Then
            cena = 6000
        End If
        If RadioButton3.Checked And RadioButton6.Checked Then
            cena = 12000
        End If
        Label3.Text = cena
        Button2.BackColor = System.Drawing.Color.FromName("Red")
    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        cena = 2000
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        cena = 3000
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        cena = 4000
    End Sub

    Private Sub RadioButton5_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton5.CheckedChanged
        cena = cena
    End Sub

    Private Sub RadioButton6_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton6.CheckedChanged
        cena = cena * 2
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If RadioButton1.Checked And RadioButton5.Checked Then
            cena = 2000
        End If
        If RadioButton2.Checked And RadioButton5.Checked Then
            cena = 3000
        End If
        If RadioButton3.Checked And RadioButton5.Checked Then
            cena = 6000
        End If
        If RadioButton1.Checked And RadioButton6.Checked Then
            cena = 4000
        End If
        If RadioButton2.Checked And RadioButton6.Checked Then
            cena = 6000
        End If
        If RadioButton3.Checked And RadioButton6.Checked Then
            cena = 12000
        End If
        Label3.Text = cena
        Button3.BackColor = System.Drawing.Color.FromName("Red")
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If RadioButton1.Checked And RadioButton5.Checked Then
            cena = 2000
        End If
        If RadioButton2.Checked And RadioButton5.Checked Then
            cena = 3000
        End If
        If RadioButton3.Checked And RadioButton5.Checked Then
            cena = 6000
        End If
        If RadioButton1.Checked And RadioButton6.Checked Then
            cena = 4000
        End If
        If RadioButton2.Checked And RadioButton6.Checked Then
            cena = 6000
        End If
        If RadioButton3.Checked And RadioButton6.Checked Then
            cena = 12000
        End If
        Label3.Text = cena
        Button4.BackColor = System.Drawing.Color.FromName("Red")
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        If RadioButton1.Checked And RadioButton5.Checked Then
            cena = 2000
        End If
        If RadioButton2.Checked And RadioButton5.Checked Then
            cena = 3000
        End If
        If RadioButton3.Checked And RadioButton5.Checked Then
            cena = 6000
        End If
        If RadioButton1.Checked And RadioButton6.Checked Then
            cena = 4000
        End If
        If RadioButton2.Checked And RadioButton6.Checked Then
            cena = 6000
        End If
        If RadioButton3.Checked And RadioButton6.Checked Then
            cena = 12000
        End If
        Label3.Text = cena
        Button5.BackColor = System.Drawing.Color.FromName("Red")
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        If RadioButton1.Checked And RadioButton5.Checked Then
            cena = 2000
        End If
        If RadioButton2.Checked And RadioButton5.Checked Then
            cena = 3000
        End If
        If RadioButton3.Checked And RadioButton5.Checked Then
            cena = 6000
        End If
        If RadioButton1.Checked And RadioButton6.Checked Then
            cena = 4000
        End If
        If RadioButton2.Checked And RadioButton6.Checked Then
            cena = 6000
        End If
        If RadioButton3.Checked And RadioButton6.Checked Then
            cena = 12000
        End If
        Label3.Text = cena
        Button6.BackColor = System.Drawing.Color.FromName("Red")
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        If RadioButton1.Checked And RadioButton5.Checked Then
            cena = 2000
        End If
        If RadioButton2.Checked And RadioButton5.Checked Then
            cena = 3000
        End If
        If RadioButton3.Checked And RadioButton5.Checked Then
            cena = 6000
        End If
        If RadioButton1.Checked And RadioButton6.Checked Then
            cena = 4000
        End If
        If RadioButton2.Checked And RadioButton6.Checked Then
            cena = 6000
        End If
        If RadioButton3.Checked And RadioButton6.Checked Then
            cena = 12000
        End If
        Label3.Text = cena
        Button7.BackColor = System.Drawing.Color.FromName("Red")
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        If RadioButton1.Checked And RadioButton5.Checked Then
            cena = 2000
        End If
        If RadioButton2.Checked And RadioButton5.Checked Then
            cena = 3000
        End If
        If RadioButton3.Checked And RadioButton5.Checked Then
            cena = 6000
        End If
        If RadioButton1.Checked And RadioButton6.Checked Then
            cena = 4000
        End If
        If RadioButton2.Checked And RadioButton6.Checked Then
            cena = 6000
        End If
        If RadioButton3.Checked And RadioButton6.Checked Then
            cena = 12000
        End If
        Label3.Text = cena
        Button8.BackColor = System.Drawing.Color.FromName("Red")
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        If RadioButton1.Checked And RadioButton5.Checked Then
            cena = 2000
        End If
        If RadioButton2.Checked And RadioButton5.Checked Then
            cena = 3000
        End If
        If RadioButton3.Checked And RadioButton5.Checked Then
            cena = 6000
        End If
        If RadioButton1.Checked And RadioButton6.Checked Then
            cena = 4000
        End If
        If RadioButton2.Checked And RadioButton6.Checked Then
            cena = 6000
        End If
        If RadioButton3.Checked And RadioButton6.Checked Then
            cena = 12000
        End If
        Label3.Text = cena
        Button9.BackColor = System.Drawing.Color.FromName("Red")
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        If RadioButton1.Checked And RadioButton5.Checked Then
            cena = 2000
        End If
        If RadioButton2.Checked And RadioButton5.Checked Then
            cena = 3000
        End If
        If RadioButton3.Checked And RadioButton5.Checked Then
            cena = 6000
        End If
        If RadioButton1.Checked And RadioButton6.Checked Then
            cena = 4000
        End If
        If RadioButton2.Checked And RadioButton6.Checked Then
            cena = 6000
        End If
        If RadioButton3.Checked And RadioButton6.Checked Then
            cena = 12000
        End If
        Label3.Text = cena
        Button10.BackColor = System.Drawing.Color.FromName("Red")
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        If RadioButton1.Checked And RadioButton5.Checked Then
            cena = 2000
        End If
        If RadioButton2.Checked And RadioButton5.Checked Then
            cena = 3000
        End If
        If RadioButton3.Checked And RadioButton5.Checked Then
            cena = 6000
        End If
        If RadioButton1.Checked And RadioButton6.Checked Then
            cena = 4000
        End If
        If RadioButton2.Checked And RadioButton6.Checked Then
            cena = 6000
        End If
        If RadioButton3.Checked And RadioButton6.Checked Then
            cena = 12000
        End If
        Label3.Text = cena
        Button11.BackColor = System.Drawing.Color.FromName("Red")
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        If RadioButton1.Checked And RadioButton5.Checked Then
            cena = 2000
        End If
        If RadioButton2.Checked And RadioButton5.Checked Then
            cena = 3000
        End If
        If RadioButton3.Checked And RadioButton5.Checked Then
            cena = 6000
        End If
        If RadioButton1.Checked And RadioButton6.Checked Then
            cena = 4000
        End If
        If RadioButton2.Checked And RadioButton6.Checked Then
            cena = 6000
        End If
        If RadioButton3.Checked And RadioButton6.Checked Then
            cena = 12000
        End If
        Label3.Text = cena
        Button12.BackColor = System.Drawing.Color.FromName("Red")
    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        Timer1.Enabled = True
    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        Timer1.Enabled = False
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        k = k + 1
        If k = 1 Then PictureBox1.Image = My.Resources._1
        If k = 2 Then PictureBox1.Image = My.Resources._2
        If k = 3 Then PictureBox1.Image = My.Resources._3
        If k = 4 Then PictureBox1.Image = My.Resources._4 : k = 0
    End Sub
End Class
